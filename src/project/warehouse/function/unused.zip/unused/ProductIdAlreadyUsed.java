package project.warehouse.function.unused;

//  @author jirawat
public class ProductIdAlreadyUsed extends Exception {
    public ProductIdAlreadyUsed() {
        super();
    }
}