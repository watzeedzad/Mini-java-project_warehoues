package project.warehouse.function.unused;

//  @author jirawat
public class InputProductAmountInvalid extends Exception {
    public InputProductAmountInvalid() {
        super("Input product amount invalid");
    }
}