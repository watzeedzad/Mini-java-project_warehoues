package project.warehouse.function.unused;

//  @author jirawat
public class UpdateProductAmount extends Exception {
    public UpdateProductAmount() {
        super("Update product amount!");
    }
}