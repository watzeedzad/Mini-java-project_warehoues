package project.warehouse.function.unused;

//  @author jirawat
public class ProductNameAlreadyUsed extends Exception {
    public ProductNameAlreadyUsed() {
        super();
    }
}