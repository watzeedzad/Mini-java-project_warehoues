package project.warehouse.function.unused;

//  @author jirawat
public class ProductNotFound extends Exception {
    public ProductNotFound() {
        super();
    }
}